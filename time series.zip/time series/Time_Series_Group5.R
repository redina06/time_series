# =================================================================
# TIME SERIES ANALYSIS: MONTHLY AVERAGE TEMPERATURES — DUBUQUE, IA
# Group 5  |  Submission: May 8, 2026 G.C.
# Dataset: tempdub | Period: Jan 1964 – Dec 1975 
# =================================================================

# 0. PACKAGES ─────────────────────────────────────────────────────
required_packages <- c("TSA", "tseries", "forecast")
install_if_missing <- function(pkg) {
  if (!requireNamespace(pkg, quietly=TRUE))
    install.packages(pkg, repos="https://cloud.r-project.org")
}
invisible(lapply(required_packages, install_if_missing))
library(TSA); library(tseries); library(forecast)
set.seed(42)

# 1. DATA LOADING ────────────────────────────────────────────────
data(tempdub)
temp_ts <- ts(tempdub, start = c(1964, 1), frequency = 12)  # CORRECT
summary(temp_ts)
cat("Length:", length(temp_ts), "| Missing:", sum(is.na(temp_ts)), "\n")

# 2. EXPLORATORY VISUALIZATION ────────────────────────────────────
plot(temp_ts, main="Monthly Avg Temp — Dubuque (1964–1975)",
     ylab="Temperature (°F)", col="steelblue", lwd=1.5)
grid(); abline(h=mean(temp_ts), col="red", lty=2)
par(mfrow=c(2,1))
acf(temp_ts,  lag.max=48, main="ACF",  col="navy",      lwd=2)
pacf(temp_ts, lag.max=48, main="PACF", col="darkgreen", lwd=2)
par(mfrow=c(1,1))
monthplot(temp_ts)
spec.pgram(temp_ts, taper=0.1, log="no")
abline(v=1/12, col="red", lty=2, lwd=2)

# 3. DECOMPOSITION ───────────────────────────────────────────────
decomp        <- decompose(temp_ts, type="additive")
trend_comp    <- decomp$trend
seasonal_comp <- decomp$seasonal
random_comp   <- decomp$random
seasonal_indices <- decomp$figure
months_abbr <- c("Jan","Feb","Mar","Apr","May","Jun",
              "Jul","Aug","Sep","Oct","Nov","Dec")
plot(decomp)

# 4. STATIONARITY TESTS ──────────────────────────────────────────
adf.test(temp_ts)                              # ADF
kpss.test(temp_ts, null="Level")              # KPSS level
kpss.test(temp_ts, null="Trend")              # KPSS trend
Box.test(temp_ts, lag=12, type="Ljung-Box")   # LB lag 12
Box.test(temp_ts, lag=24, type="Ljung-Box")   # LB lag 24

# 5. TREND ESTIMATION ────────────────────────────────────────────
trend_ma <- filter(temp_ts, rep(1/12,12), sides=2)
plot(temp_ts, col="gray60", lwd=1)
lines(trend_ma, col="red", lwd=2.8)
# Linear trend test
trend_lm <- lm(as.numeric(trend_ma[!is.na(trend_ma)]) ~
               as.numeric(time(trend_ma)[!is.na(trend_ma)]))
print(summary(trend_lm))

# 6. SEASONAL COMPONENT ──────────────────────────────────────────
plot(seasonal_comp, col="darkgreen")
barplot(seasonal_indices, names.arg=months_abbr,
        col=ifelse(seasonal_indices>0,"tomato","steelblue"),
        border="white")

# 7. RESIDUAL DIAGNOSTICS ────────────────────────────────────────
residuals_clean <- na.omit(random_comp)   # 'residuals_clean' not 'residuals'
par(mfrow=c(2,2))
acf(residuals_clean,  lag.max=36, main="ACF of Residuals")
pacf(residuals_clean, lag.max=36, main="PACF of Residuals")
hist(residuals_clean, freq=FALSE, col="lightblue", breaks=20)
curve(dnorm(x,mean(residuals_clean),sd(residuals_clean)),add=TRUE,col="red")
qqnorm(residuals_clean); qqline(residuals_clean, col="red")
par(mfrow=c(1,1))
Box.test(residuals_clean, lag=12, type="Ljung-Box")
Box.test(residuals_clean, lag=24, type="Ljung-Box")
shapiro.test(as.numeric(residuals_clean)[1:min(5000,length(residuals_clean))])

# 8. VARIANCE DECOMPOSITION ─────────────────────────────────────
var_orig <- var(temp_ts)
cat("Seasonal:", round(var(seasonal_comp,na.rm=TRUE)/var_orig*100,1),"%\n")
cat("Residual:", round(var(random_comp, na.rm=TRUE)/var_orig*100,1),"%\n")
cat("Trend   :", round(var(trend_ma,   na.rm=TRUE)/var_orig*100,1),"%\n")

# 9. SARIMA ──────────────────────────────────────────────────────
temp_sdiff <- diff(temp_ts, lag=12)
adf.test(temp_sdiff)
par(mfrow=c(2,1))
acf(temp_sdiff,  lag.max=48, main="ACF: Seasonally Differenced")
pacf(temp_sdiff, lag.max=48, main="PACF: Seasonally Differenced")
par(mfrow=c(1,1))
fit_sarima <- auto.arima(temp_ts, stepwise=FALSE, approximation=FALSE,
                         seasonal=TRUE, ic="aic", max.p=3, max.q=3,
                         max.P=2, max.Q=2, max.d=1, max.D=1, trace=TRUE)
print(summary(fit_sarima))
checkresiduals(fit_sarima)
fc_sarima <- forecast(fit_sarima, h=24, level=c(80,95))
plot(fc_sarima, main="SARIMA Forecast (1976–1977)")

# 10. HOLT-WINTERS ───────────────────────────────────────────────
hw_fit <- HoltWinters(temp_ts, seasonal="additive")
hw_fc  <- forecast(hw_fit, h=24, level=c(80,95))
plot(hw_fc, main="Holt-Winters Forecast (1976–1977)")

# 11. MODEL COMPARISON ───────────────────────────────────────────
print(round(accuracy(fit_sarima), 4))
print(round(accuracy(hw_fc)[1,],  4))

# 12. OUT-OF-SAMPLE HOLDOUT (1974–1975) ─────────────────────────
train_ts <- window(temp_ts, end=c(1973,12))
test_ts  <- window(temp_ts, start=c(1974,1))
fit_s_tr <- auto.arima(train_ts, stepwise=FALSE, approximation=FALSE,
                        seasonal=TRUE, ic="aic", max.p=3, max.q=3,
                        max.P=2, max.Q=2, trace=FALSE)
hw_tr    <- HoltWinters(train_ts, seasonal="additive")
fc_s_oos <- forecast(fit_s_tr, h=24)
fc_h_oos <- forecast(hw_tr,    h=24)
print(round(accuracy(fc_s_oos, test_ts), 4))
print(round(accuracy(fc_h_oos, test_ts), 4))

# 13. SESSION INFO ───────────────────────────────────────────────
sessionInfo()
# =================================================================
# END OF SCRIPT
# =================================================================
